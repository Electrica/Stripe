<?php

switch ($modx->event->name){
    case 'OnLoadWebDocument':
        //$modx->regClientScript(MODX_ASSETS_URL . 'components/stripe/web/js/stripe.js');
        break;
}
