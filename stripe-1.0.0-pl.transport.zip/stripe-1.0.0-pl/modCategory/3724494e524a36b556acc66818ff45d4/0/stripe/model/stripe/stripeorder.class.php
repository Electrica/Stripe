<?php

class StripeOrder extends xPDOSimpleObject{

}