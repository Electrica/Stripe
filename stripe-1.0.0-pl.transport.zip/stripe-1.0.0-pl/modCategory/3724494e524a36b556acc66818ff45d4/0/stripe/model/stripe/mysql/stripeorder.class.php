<?php
require_once (dirname(__DIR__) . '/stripeorder.class.php');
class StripeOrder_mysql extends StripeOrder {}