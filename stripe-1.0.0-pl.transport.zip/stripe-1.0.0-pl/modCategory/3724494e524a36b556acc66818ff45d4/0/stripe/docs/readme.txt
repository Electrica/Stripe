--------------------
Stripe
--------------------
Author: Electrica <info@modx.kz>
--------------------