<?php
/**
 * Russian permissions Lexicon Entries for Stripe
 *
 * @package Stripe
 * @subpackage lexicon
 */
$_lang['stripe_save'] = 'Permission for save/update data.';