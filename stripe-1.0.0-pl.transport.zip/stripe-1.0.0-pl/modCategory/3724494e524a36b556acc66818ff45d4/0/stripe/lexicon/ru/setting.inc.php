<?php

$_lang['area_stripe_main'] = 'Основные';

$_lang['stripe_publishable_key'] = 'Публичный ключ';
$_lang['stripe_secret_key'] = 'Секретный ключ';
$_lang['stripe_currency'] = 'Валюта';
$_lang['stripe_success_url'] = 'Путь к коннектору успешной оплаты';
$_lang['stripe_cancel_url'] = 'Путь к коннектору неудачной оплаты';
$_lang['stripe_confirm_page'] = 'id страницы, созданной автоматически при установке пакета';
$_lang['stripe_thanks_page'] = 'id страницы Спасибо за покупку';